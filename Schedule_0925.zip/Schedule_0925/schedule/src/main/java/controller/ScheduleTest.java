////package controller;
////
////import java.io.IOException;
////import java.io.PrintWriter;
////import java.sql.Connection;
////import java.sql.DriverManager;
////import java.sql.PreparedStatement;
////import java.sql.ResultSet;
////import java.sql.SQLException;
////
////import javax.servlet.ServletException;
////import javax.servlet.annotation.WebServlet;
////import javax.servlet.http.HttpServlet;
////import javax.servlet.http.HttpServletRequest;
////import javax.servlet.http.HttpServletResponse;
////import javax.servlet.http.HttpSession;
////
/////**
//// * Servlet implementation class ScheduleTest
//// */
////@WebServlet("/ScheduleTest")
////public class ScheduleTest extends HttpServlet {
////	
////	
////	 protected Connection conn = null;
////	 
////	 
////	private static final long serialVersionUID = 1L;
////	public void init() throws ServletException {
////        String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
////        String JDBC_URL = "jdbc:mysql://192.168.1.21/forest_db?characterEncoding=UTF-8&useSSL=false";
////        String USER_ID = "forest_user";
////        String USER_PASS = "forest_pass";
////
////        try {
////            Class.forName(DRIVER_NAME);
////            conn = DriverManager.getConnection(JDBC_URL, USER_ID, USER_PASS);
////        } catch (ClassNotFoundException e) {
////            log("ClassNotFoundException: " + e.getMessage());
////        } catch (SQLException e) {
////            log("SQLException: " + e.getMessage());
////        } catch (Exception e) {
////            log("Exception: " + e.getMessage());
////            e.printStackTrace();
////            throw new ServletException("初期化エラー: " + e.getMessage(), e);
////        }
////    }
////    /**
////     * @see HttpServlet#HttpServlet()
////     */
////    public ScheduleTest() {
////        super();
////        // TODO Auto-generated constructor stub
////    }
////
////	/**
////	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
////	 */
////	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
////		// TODO Auto-generated method stub
//////		response.getWriter().append("Served at: ").append(request.getContextPath());
//////	}
////
////		
////		
////		res.setContentType("text/html; charset=UTF-8");
////        PrintWriter out = res.getWriter();
////        
////        String user = req.getParameter("user");
////        String pass = req.getParameter("pass");
////
////        HttpSession session = req.getSession(true);
////
////        System.out.println("チェック");
////        
////        boolean check = authUser(user, pass, session);
////        if (check){
////            /* 認証済みにセット */
////            session.setAttribute("login", "OK");
////
////            /* 認証成功後は必ずMonthViewサーブレットを呼びだす */
////            res.sendRedirect("MonthView7");
////        }else{
////            /* 認証に失敗したら、ログイン画面に戻す */
////            session.setAttribute("status", "Not Auth");
////            res.sendRedirect("LoginPage1");
////        }
////    }
////	 protected boolean authUser(String user, String pass, HttpSession session){
////	        if (user == null || user.length() == 0 || pass == null || pass.length() == 0){
////	            return false;
////	        }
////
////	        try {
////	            String sql = "SELECT * FROM usertable WHERE user = ? && pass = ?";
////	            PreparedStatement pstmt = conn.prepareStatement(sql);
////
////	            pstmt.setString(1, user);
////	            pstmt.setString(2, pass);
////	            ResultSet rs = pstmt.executeQuery();
////
////	            if (rs.next()){
////	                int userid = rs.getInt("id");
////	                int roll = rs.getInt("roll");
////	                String username = rs.getString("user");
////
////	                session.setAttribute("userid", Integer.toString(userid));
////	                session.setAttribute("roll", Integer.toString(roll));
////	                session.setAttribute("username", username);
////
////	                return true;
////	            }else{
////	                return false;
////	            }
////	        }catch (SQLException e){
////	            log("SQLException:" + e.getMessage());
////	            return false;
////	        }
////	    }
////	
//	
//	
//	/**
//	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
//	 */
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		doGet(request, response);
//	}
//
//}
