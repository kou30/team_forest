package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginPage1")
public class LoginPage1 extends HttpServlet {
    protected Connection conn = null;

    public void init() throws ServletException {
        String DRIVER_NAME = "com.mysql.cj.jdbc.Driver";
        String JDBC_URL = "jdbc:mysql://192.168.1.21/forest_db?characterEncoding=UTF-8&useSSL=false";
        String USER_ID = "forest_user";
        String USER_PASS = "forest_pass";

        try {
            Class.forName(DRIVER_NAME);
            conn = DriverManager.getConnection(JDBC_URL, USER_ID, USER_PASS);
        } catch (ClassNotFoundException e) {
            log("ClassNotFoundException: " + e.getMessage());
        } catch (SQLException e) {
            log("SQLException: " + e.getMessage());
        } catch (Exception e) {
            log("Exception: " + e.getMessage());
            e.printStackTrace();
            throw new ServletException("初期化エラー: " + e.getMessage(), e);
        }
    }

    
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        res.setContentType("text/html; charset=UTF-8");
        PrintWriter out = res.getWriter();

        out.println("<html>");
        out.println("<head>");
        
        out.println("<title>ログインページ</title>");
        out.println("</head>");
        out.println("<body>");
   

        out.println("<h1>スケジュール帳へようこそ</h1>");
        out.println("<p>スケジュール帳をご利用頂くにはまずログインして頂く必要があります。ユーザー名とパスワードを入力してログインして下さい。</p>");

        HttpSession session = req.getSession(true);

        /* 認証失敗から呼び出されたのかどうか */
        Object status = session.getAttribute("status");

        if (status != null){
            out.println("<p>認証に失敗しました</p>");
            out.println("<p>再度ユーザー名とパスワードを入力して下さい</p>");

            session.setAttribute("status", null);
        }

        out.println("<form method=\"POST\" action=\"LoginCheck1\" name=\"loginform\">");
        out.println("<table>");
        out.println("<tr>");
        out.println("<td>ユーザー名</td>");
        out.println("<td><input type=\"text\" name=\"user\" size=\"32\"></td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td>パスワード</td>");
        out.println("<td><input type=\"password\" name=\"pass\" size=\"32\"></td>");
        out.println("</tr>");
        out.println("<tr>");
        out.println("<td><input type=\"submit\" value=\"login\"></td>");
        out.println("<td><input type=\"reset\" value=\"reset\"></td>");
        out.println("</tr>");
        out.println("</table>");
        out.println("</form>");

        out.println("</body>");
        out.println("</html>");
    }
}